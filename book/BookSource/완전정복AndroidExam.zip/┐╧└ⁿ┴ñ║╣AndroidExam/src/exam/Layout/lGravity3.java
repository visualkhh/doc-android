package exam.Layout;

import android.app.*;
import android.os.*;
import exam.AndroidExam.*;

public class lGravity3 extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_lgravity3);
    }
}