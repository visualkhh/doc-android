package exam.Widget;

import android.app.*;
import android.content.res.*;
import android.os.*;
import android.widget.*;
import exam.AndroidExam.*;

public class ReadResource2 extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.widget_readresource2);
	}
}