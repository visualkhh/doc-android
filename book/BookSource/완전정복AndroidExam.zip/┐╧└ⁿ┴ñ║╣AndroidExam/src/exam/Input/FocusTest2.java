package exam.Input;

import android.app.*;
import android.os.*;
import exam.AndroidExam.*;

public class FocusTest2 extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.input_focustest2);
	}
}