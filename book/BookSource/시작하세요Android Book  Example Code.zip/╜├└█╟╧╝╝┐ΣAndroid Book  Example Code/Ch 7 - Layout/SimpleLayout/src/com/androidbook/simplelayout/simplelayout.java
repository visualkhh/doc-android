package com.androidbook.simplelayout;

import android.os.Bundle;

public class simplelayout extends layout_menu_class {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    	
    }

    



}