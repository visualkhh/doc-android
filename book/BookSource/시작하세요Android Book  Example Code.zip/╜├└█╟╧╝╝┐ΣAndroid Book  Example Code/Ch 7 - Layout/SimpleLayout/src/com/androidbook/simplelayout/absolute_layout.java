package com.androidbook.simplelayout;

import android.os.Bundle;

public class absolute_layout extends layout_menu_class {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.absolute_layout);
	}

}
