This directory contains all the example source files which accompany the book. 

Each chapter with source code has its own subdirectory, which may contain one 
or more projects. These projects were created using the Eclipse IDE. 

The code contents of each example is distributed "AS IS", without any warranty 
or conditions of any kind, and are for teaching purposes only. 

