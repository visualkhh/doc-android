package com.paad.chapter5;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Stub BroadcastReceiver used to demonstrate Implicit Intents */
public class MyIntentReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(Context context, Intent intent) {
    //TODO React to the Intent received.
  }
  
}
