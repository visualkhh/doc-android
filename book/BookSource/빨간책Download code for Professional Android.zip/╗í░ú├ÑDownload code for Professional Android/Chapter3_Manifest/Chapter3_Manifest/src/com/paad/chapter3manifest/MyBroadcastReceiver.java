package com.paad.chapter3manifest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

//Dummy BroadcastReciever for demonstrating the Manifest
public class MyBroadcastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
	}

}
