package com.paad.chapter3manifest;

import android.app.Activity;
import android.os.Bundle;

// Dummy Activity for demonstrating the Manifest
public class MyActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
    }
}