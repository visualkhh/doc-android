Manifest for the file Download code for Professional Android.zip

The file you downloaded should contain the following files:

Chapter10_Code_Snipppets.zip
Chapter10_Code_Snipppets_Bluetooth.zip
Chapter10_Sample_Compass.zip
Chapter10_Sample_Speedometer.zip
Chapter11_Code_Snippets.zip
Chapter11_Sample_Compass.zip
Chapter11_Sample_ContentSlider.zip
Chapter11_Sample_Earthquake.zip
Chapter2_Code_Snippets.zip
Chapter2_Sample_Todo_List.zip
Chapter3_Code_Snippets.zip
Chapter3_Manifest.zip
Chapter3_Sample_Todo_List.zip
Chapter4_Code_Snippets.zip
Chapter4_Sample_Compass.zip
Chapter4_Sample_Todo_List.zip
Chapter4_Sample_Todo_List_2.zip
Chapter5_Code_Snippets.zip
Chapter5_Sample_ContactPicker.zip
Chapter5_Sample_Earthquake.zip
Chapter5_Sample_Todo_List.zip
Chapter6_Code_Snippets.zip
Chapter6_Sample_Earthquake.zip
Chapter6_Sample_Earthquake_2.zip
Chapter6_Sample_Todo_List.zip
Chapter6_Sample_Todo_List_2.zip
Chapter7_Code_Snippets.zip
Chapter7_Sample_Earthquake.zip
Chapter7_Sample_WhereAmI.zip
Chapter7_Sample_WhereAmI_2.zip
Chapter7_Sample_WhereAmI_3.zip
Chapter7_Sample_WhereAmI_4.zip
Chapter7_Sample_WhereAmI_5.zip
Chapter8_Code_Snippets.zip
Chapter8_Sample_Earthquake.zip
Chapter8_Sample_Earthquake_2.zip
Chapter8_Sample_Earthquake_3.zip
Chapter8_Sample_Earthquake_4.zip
Chapter9_Code_Snippets.zip
Chapter9_GTalk_Code_Snippets.zip
Chapter9_Sample_EmergencyResponder.zip
Chapter9_Sample_EmergencyResponder_2.zip
